#!/bin/bash
# 萱萱单词闯关 - 一键更新脚本
# 用法: cd ~/xuanxuan_py && ./update.sh

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

BACKUP_DIR="backup_$(date +%Y%m%d_%H%M%S)"
TARBALL="backend_v4.tar.gz"
URL="https://raw.githubusercontent.com/sallyhushan/Xuanxuan_words/main/xuanxuan_py_v4.tar.gz"

echo "📦 备份数据到 $BACKUP_DIR ..."
mkdir -p "$BACKUP_DIR"
cp -r data "$BACKUP_DIR/" 2>/dev/null || true
cp server.py "$BACKUP_DIR/" 2>/dev/null || true
cp index.html "$BACKUP_DIR/" 2>/dev/null || true

echo "⬇️  下载最新版本 ..."
rm -f "$TARBALL"
wget -q -O "$TARBALL" "$URL"

echo "🛑 停止旧服务 ..."
pkill -f "python3.*server.py" 2>/dev/null || true
sleep 1

echo "📂 解压新包 ..."
tar xzf "$TARBALL"
rm -f "$TARBALL"

echo "🚀 启动服务 ..."
nohup python3 server.py > server.log 2>&1 &
sleep 2

echo "✅ 完成！"
echo "   数据备份: $SCRIPT_DIR/$BACKUP_DIR"
echo "   访问地址: http://$(hostname -I | awk '{print $1}'):3000"
echo "   日志查看: tail -f $SCRIPT_DIR/server.log"
