#!/bin/bash
# ============================================================
# 萱萱单词闯关 - 后端自动部署脚本
# 运行方式：chmod +x deploy.sh && ./deploy.sh
# ============================================================

set -e  # 遇到错误立即退出

# ------------------- 配置区（根据你的环境修改） -------------------

# 你的阿里云ECS公网IP或域名
# 示例：SERVER_IP="47.88.12.34" 或 SERVER_IP="xuanxuan.yourdomain.com"
SERVER_IP="${SERVER_IP:-YOUR_ECS_IP}"

# 后端服务端口（默认3000，如需改请同时改安全组）
PORT="${PORT:-3000}"

# 是否使用HTTPS（如果你有域名+SSL证书）
USE_HTTPS="${USE_HTTPS:-false}"

# 数据持久化目录（默认当前目录下的 data/）
DATA_DIR="${DATA_DIR:-./data}"

# ------------------- 颜色输出 -------------------
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

info() { echo -e "${BLUE}[INFO]${NC} $1"; }
ok() { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err() { echo -e "${RED}[ERR]${NC} $1"; }

# ------------------- 预检查 -------------------
info "开始部署萱萱单词记录后端..."

if [ "$SERVER_IP" = "YOUR_ECS_IP" ]; then
    err "请先编辑脚本，将 SERVER_IP 改为你的ECS公网IP"
    echo "  编辑方式：vim deploy.sh，找到 SERVER_IP=\"YOUR_ECS_IP\" 这一行"
    exit 1
fi

# 检查Node.js
info "检查 Node.js 环境..."
if ! command -v node &> /dev/null; then
    warn "未检测到 Node.js，开始安装..."
    if command -v apt &> /dev/null; then
        # Ubuntu/Debian
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
        sudo apt-get install -y nodejs
    elif command -v yum &> /dev/null; then
        # CentOS/RHEL
        curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
        sudo yum install -y nodejs
    else
        err "无法自动安装 Node.js，请手动安装后重试"
        exit 1
    fi
fi

NODE_VERSION=$(node --version | sed 's/v//')
info "Node.js 版本: $NODE_VERSION"

if [ "$(printf '%s\n' "18.0.0" "$NODE_VERSION" | sort -V | head -n1)" != "18.0.0" ]; then
    warn "Node.js 版本低于 18，建议升级"
fi

# 检查npm
if ! command -v npm &> /dev/null; then
    err "npm 未安装"
    exit 1
fi

# ------------------- 下载后端 -------------------
BACKEND_DIR="xuanxuan_backend"
TAR_URL="https://raw.githubusercontent.com/sallyhushan/Xuanxuan_words/main/xuanxuan_backend.tar.gz"

info "下载后端代码..."
if [ -d "$BACKEND_DIR" ]; then
    warn "目录 $BACKEND_DIR 已存在，先备份..."
    mv "$BACKEND_DIR" "${BACKEND_DIR}_backup_$(date +%Y%m%d%H%M%S)"
fi

wget -q "$TAR_URL" -O /tmp/xuanxuan_backend.tar.gz
if [ ! -f /tmp/xuanxuan_backend.tar.gz ]; then
    err "下载失败，请检查网络"
    exit 1
fi

tar xzf /tmp/xuanxuan_backend.tar.gz
ok "后端代码已解压到 $BACKEND_DIR/"

cd "$BACKEND_DIR"

# ------------------- 安装依赖 -------------------
info "安装依赖..."
npm install --production
ok "依赖安装完成"

# ------------------- 配置环境变量 -------------------
info "生成环境配置..."
cat > .env << EOF
PORT=$PORT
DATA_DIR=$DATA_DIR
NODE_ENV=production
EOF
ok "环境配置已写入 .env"

# ------------------- 防火墙配置 -------------------
info "配置防火墙..."
if command -v ufw &> /dev/null; then
    sudo ufw allow "$PORT/tcp" || true
    ok "ufw 已放行端口 $PORT"
elif command -v firewall-cmd &> /dev/null; then
    sudo firewall-cmd --permanent --add-port="$PORT/tcp" || true
    sudo firewall-cmd --reload || true
    ok "firewalld 已放行端口 $PORT"
else
    warn "未检测到 ufw/firewalld，请手动在阿里云安全组放行端口 $PORT"
fi

# 阿里云安全组提示
echo ""
echo -e "${YELLOW}重要提醒：${NC}"
echo "请登录阿里云控制台 → ECS → 安全组 → 配置规则"
echo "添加入方向规则："
echo "  协议类型: 自定义TCP"
echo "  端口范围: $PORT/$PORT"
echo "  授权对象: 0.0.0.0/0（或你的前端IP）"
echo ""

# ------------------- PM2 配置 -------------------
info "配置 PM2 守护进程..."
if ! command -v pm2 &> /dev/null; then
    info "安装 PM2..."
    sudo npm install -g pm2
fi

pm2 delete xuanxuan-records 2>/dev/null || true
pm2 start server.js --name xuanxuan-records --env production
pm2 save
pm2 startup 2>/dev/null || true
ok "PM2 配置完成"

# ------------------- Nginx 反向代理（可选） -------------------
if [ "$USE_HTTPS" = "true" ] && command -v nginx &> /dev/null; then
    info "配置 Nginx 反向代理..."
    
    # 生成Nginx配置
    NGINX_CONF="/etc/nginx/conf.d/xuanxuan.conf"
    if [ "$USE_HTTPS" = "true" ]; then
        sudo tee "$NGINX_CONF" > /dev/null << EOF
server {
    listen 80;
    server_name $SERVER_IP;
    
    location / {
        return 301 https://\$host\$request_uri;
    }
}

server {
    listen 443 ssl;
    server_name $SERVER_IP;
    
    # SSL证书路径（请替换为你的实际路径）
    # ssl_certificate /path/to/your.crt;
    # ssl_certificate_key /path/to/your.key;
    
    location /api/ {
        proxy_pass http://localhost:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
}
EOF
    else
        sudo tee "$NGINX_CONF" > /dev/null << EOF
server {
    listen 80;
    server_name $SERVER_IP;
    
    location /api/ {
        proxy_pass http://localhost:$PORT;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
    }
}
EOF
    fi
    
    sudo nginx -t && sudo systemctl reload nginx
    ok "Nginx 配置完成"
fi

# ------------------- 健康检查 -------------------
info "等待服务启动..."
sleep 3

HEALTH_URL="http://localhost:$PORT/api/health"
if curl -s "$HEALTH_URL" > /dev/null; then
    ok "服务运行正常！"
    RESPONSE=$(curl -s "$HEALTH_URL")
    echo "  健康检查响应: $RESPONSE"
else
    warn "健康检查未通过，查看日志..."
    pm2 logs xuanxuan-records --lines 20
fi

# ------------------- 完成信息 -------------------
echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  部署完成！${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "服务地址: ${BLUE}http://$SERVER_IP:$PORT${NC}"
echo -e "健康检查: ${BLUE}http://$SERVER_IP:$PORT/api/health${NC}"
echo -e "查询记录: ${BLUE}http://$SERVER_IP:$PORT/api/records?student=萱萱${NC}"
echo ""
echo -e "常用命令:"
echo "  pm2 status          - 查看服务状态"
echo "  pm2 logs            - 查看实时日志"
echo "  pm2 restart xuanxuan-records  - 重启服务"
echo "  pm2 stop xuanxuan-records     - 停止服务"
echo ""
echo -e "数据目录: ${BLUE}$(pwd)/$DATA_DIR${NC}"
echo -e "日志目录: ${BLUE}~/.pm2/logs/${NC}"
echo ""
echo -e "${YELLOW}下一步：${NC}"
echo "1. 确认阿里云安全组已放行端口 $PORT"
echo "2. 修改前端 index.html 中的 API_BASE 为: ${GREEN}http://$SERVER_IP:$PORT${NC}"
echo "3. 重新上传 index.html 到 GitHub Pages"
echo ""
echo -e "${GREEN}萱萱的数据会自动飞到这里 ✈️${NC}"
