const express = require('express');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');

// 中间件
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// 确保数据目录存在
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// 生成日期目录
function getDateDir() {
  const d = new Date();
  const dir = path.join(DATA_DIR, `${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
}

// === 接收单轮闯关记录 ===
app.post('/api/record', (req, res) => {
  const record = req.body;
  
  // 基础校验
  if (!record || !record.student || !record.roundId) {
    return res.status(400).json({ error: 'missing student or roundId' });
  }
  
  const dir = getDateDir();
  const filename = `${record.student}_${record.roundId}.json`;
  const filepath = path.join(dir, filename);
  
  // 如果存在就追加（同一轮重试）
  let existing = null;
  if (fs.existsSync(filepath)) {
    try { existing = JSON.parse(fs.readFileSync(filepath, 'utf8')); } catch(e) {}
  }
  
  const final = existing 
    ? { ...existing, ...record, _uploadAttempts: (existing._uploadAttempts || 1) + 1, _lastUploadAt: new Date().toISOString() }
    : { ...record, _uploadAttempts: 1, _firstUploadAt: new Date().toISOString(), _lastUploadAt: new Date().toISOString() };
  
  fs.writeFileSync(filepath, JSON.stringify(final, null, 2));
  
  res.json({ success: true, id: filename, path: filepath });
});

// === 查询所有记录 ===
app.get('/api/records', (req, res) => {
  const { student, date } = req.query;
  let dirs = fs.readdirSync(DATA_DIR).filter(d => /^\d{8}$/.test(d)).sort();
  
  if (date) dirs = dirs.filter(d => d === date);
  
  let records = [];
  for (const dir of dirs) {
    const files = fs.readdirSync(path.join(DATA_DIR, dir)).filter(f => f.endsWith('.json'));
    for (const f of files) {
      if (student && !f.startsWith(student + '_')) continue;
      try {
        const data = JSON.parse(fs.readFileSync(path.join(DATA_DIR, dir, f), 'utf8'));
        records.push(data);
      } catch(e) {}
    }
  }
  
  res.json({ count: records.length, records });
});

// === 健康检查 ===
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString(), dataDir: DATA_DIR });
});

app.listen(PORT, () => {
  console.log(`🚀 萱萱单词记录服务器启动`);
  console.log(`   端口: ${PORT}`);
  console.log(`   数据目录: ${DATA_DIR}`);
  console.log(`   接口:`);
  console.log(`     POST /api/record    - 提交闯关记录`);
  console.log(`     GET  /api/records   - 查询记录 (?student=萱萱&date=20260115)`);
  console.log(`     GET  /api/health    - 健康检查`);
});
