# 萱萱单词闯关 - 后端记录服务

## 部署到阿里云ECS

### 1. 安装依赖
```bash
cd xuanxuan_backend
npm install
```

### 2. 启动（开发）
```bash
npm start
# 默认监听 3000 端口
```

### 3. 生产部署（PM2）
```bash
npm install -g pm2
pm2 start server.js --name xuanxuan-records
pm2 startup
pm2 save
```

### 4. Nginx 反向代理（如果有域名）
```nginx
server {
    listen 80;
    server_name xuanxuan.yourdomain.com;
    
    location /api/ {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
    }
}
```

### 5. 防火墙放行
```bash
# 阿里云安全组 + 服务器防火墙
sudo ufw allow 3000
# 或在阿里云控制台安全组添加 3000 端口入站规则
```

## API 接口

| 方法 | 路径 | 说明 |
|---|---|---|
| POST | /api/record | 提交单轮闯关记录 |
| GET | /api/records?student=萱萱 | 查询记录 |
| GET | /api/health | 健康检查 |

### POST /api/record 请求体示例
```json
{
  "student": "萱萱",
  "roundId": "round_20260115_143052_abc123",
  "timestamp": "2026-01-15T14:30:52.123Z",
  "device": "iPhone14_Safari",
  "total": 20,
  "ok": 16,
  "bad": 4,
  "acc": 80,
  "avgTime": 3.2,
  "maxStreak": 4,
  "usedHints": 2,
  "phase": "first",
  "details": [
    {
      "word": "climate",
      "ok": true,
      "time": 2.1,
      "hint": false,
      "chosen": "气候",
      "correct": "气候"
    },
    ...
  ]
}
```
