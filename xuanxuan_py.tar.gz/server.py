#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
萱萱单词闯关 - 记录接收服务 (Python)
CentOS 7 兼容，零外部依赖
"""

import os
import json
from datetime import datetime
from http.server import HTTPServer, BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse

PORT = int(os.environ.get("PORT", 3000))
DATA_DIR = os.environ.get("DATA_DIR", "./data")


def ensure_dir(d):
    if not os.path.exists(d):
        os.makedirs(d, exist_ok=True)


def get_date_dir():
    d = datetime.now()
    dirname = os.path.join(DATA_DIR, d.strftime("%Y%m%d"))
    ensure_dir(dirname)
    return dirname


class CORSRequestHandler(BaseHTTPRequestHandler):
    def do_OPTIONS(self):
        self.send_response(200)
        self.send_cors_headers()
        self.end_headers()

    def send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Content-Type", "application/json; charset=utf-8")

    def log_message(self, fmt, *args):
        print(f"[{datetime.now().isoformat()}] {args[0]}")

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        qs = parse_qs(parsed.query)

        if path == "/api/health":
            self.send_response(200)
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "ok",
                "time": datetime.now().isoformat(),
                "dataDir": os.path.abspath(DATA_DIR)
            }, ensure_ascii=False).encode("utf-8"))
            return

        if path == "/api/records":
            student = qs.get("student", [None])[0]
            date = qs.get("date", [None])[0]
            records = []
            ensure_dir(DATA_DIR)
            dirs = sorted([d for d in os.listdir(DATA_DIR) if d.isdigit() and len(d) == 8])
            if date:
                dirs = [d for d in dirs if d == date]
            for dname in dirs:
                dpath = os.path.join(DATA_DIR, dname)
                for fname in sorted(os.listdir(dpath)):
                    if not fname.endswith(".json"):
                        continue
                    if student and not fname.startswith(student + "_"):
                        continue
                    fpath = os.path.join(dpath, fname)
                    try:
                        with open(fpath, "r", encoding="utf-8") as f:
                            records.append(json.load(f))
                    except Exception:
                        pass
            self.send_response(200)
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({
                "count": len(records),
                "records": records
            }, ensure_ascii=False).encode("utf-8"))
            return

        self.send_response(404)
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(json.dumps({"error": "not found"}, ensure_ascii=False).encode("utf-8"))

    def do_POST(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path == "/api/record":
            content_len = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_len).decode("utf-8")
            try:
                record = json.loads(body)
            except json.JSONDecodeError:
                self.send_response(400)
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps({"error": "invalid json"}, ensure_ascii=False).encode("utf-8"))
                return

            if not record.get("student") or not record.get("roundId"):
                self.send_response(400)
                self.send_cors_headers()
                self.end_headers()
                self.wfile.write(json.dumps({"error": "missing student or roundId"}, ensure_ascii=False).encode("utf-8"))
                return

            dirname = get_date_dir()
            filename = f"{record['student']}_{record['roundId']}.json"
            filepath = os.path.join(dirname, filename)

            existing = None
            if os.path.exists(filepath):
                try:
                    with open(filepath, "r", encoding="utf-8") as f:
                        existing = json.load(f)
                except Exception:
                    pass

            now = datetime.now().isoformat()
            if existing:
                final = {**existing, **record}
                final["_uploadAttempts"] = existing.get("_uploadAttempts", 1) + 1
                final["_lastUploadAt"] = now
            else:
                final = {**record, "_uploadAttempts": 1, "_firstUploadAt": now, "_lastUploadAt": now}

            with open(filepath, "w", encoding="utf-8") as f:
                json.dump(final, f, ensure_ascii=False, indent=2)

            self.send_response(200)
            self.send_cors_headers()
            self.end_headers()
            self.wfile.write(json.dumps({
                "success": True,
                "id": filename,
                "path": filepath
            }, ensure_ascii=False).encode("utf-8"))
            return

        self.send_response(404)
        self.send_cors_headers()
        self.end_headers()
        self.wfile.write(json.dumps({"error": "not found"}, ensure_ascii=False).encode("utf-8"))


if __name__ == "__main__":
    ensure_dir(DATA_DIR)
    server = HTTPServer(("0.0.0.0", PORT), CORSRequestHandler)
    print(f"🚀 萱萱单词记录服务器启动")
    print(f"   端口: {PORT}")
    print(f"   数据目录: {os.path.abspath(DATA_DIR)}")
    print(f"   接口:")
    print(f"     POST /api/record    - 提交闯关记录")
    print(f"     GET  /api/records   - 查询记录 (?student=萱萱)")
    print(f"     GET  /api/health    - 健康检查")
    print(f"")
    print(f"   按 Ctrl+C 停止")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n👋 已停止")
