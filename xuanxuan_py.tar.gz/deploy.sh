#!/bin/bash
# ============================================================
# 萱萱单词闯关 - Python后端自动部署脚本 (CentOS 7兼容)
# 运行方式：chmod +x deploy.sh && ./deploy.sh
# ============================================================

set -e

SERVER_IP="8.138.202.82"
PORT="${PORT:-3000}"
DATA_DIR="${DATA_DIR:-./data}"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

info() { echo -e "${BLUE}[INFO]${NC} $1"; }
ok() { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
err() { echo -e "${RED}[ERR]${NC} $1"; }

info "开始部署萱萱单词记录后端 (Python)..."

# 检查/安装 Python3
info "检查 Python3 环境..."
if ! command -v python3 &> /dev/null; then
    warn "未检测到 python3，尝试安装..."
    if command -v yum &> /dev/null; then
        yum install -y python3 || {
            err "yum 安装 python3 失败"
            exit 1
        }
    elif command -v apt &> /dev/null; then
        apt-get update && apt-get install -y python3 || {
            err "apt 安装 python3 失败"
            exit 1
        }
    else
        err "无法自动安装 python3，请手动安装后重试"
        exit 1
    fi
fi

PY_VERSION=$(python3 --version 2>&1)
ok "Python 版本: $PY_VERSION"

# 确认 server.py 存在
if [ ! -f "server.py" ]; then
    err "server.py 不存在，请确认在正确的目录下运行此脚本"
    exit 1
fi
ok "server.py 就绪"

# 防火墙配置
info "配置防火墙..."
if command -v firewall-cmd &> /dev/null; then
    firewall-cmd --permanent --add-port="${PORT}/tcp" 2>/dev/null || true
    firewall-cmd --reload 2>/dev/null || true
    ok "firewalld 已放行端口 $PORT"
elif command -v iptables &> /dev/null; then
    iptables -I INPUT -p tcp --dport "$PORT" -j ACCEPT 2>/dev/null || true
    service iptables save 2>/dev/null || true
    ok "iptables 已放行端口 $PORT"
else
    warn "未检测到 firewall-cmd/iptables，请手动在阿里云安全组放行端口 $PORT"
fi

# 启动服务
info "启动后端服务..."

# 杀掉旧进程
if [ -f "server.pid" ]; then
    OLD_PID=$(cat server.pid 2>/dev/null)
    if [ -n "$OLD_PID" ] && kill -0 "$OLD_PID" 2>/dev/null; then
        warn "发现旧进程 $OLD_PID，正在停止..."
        kill "$OLD_PID" || true
        sleep 2
    fi
fi

# 用 nohup 启动
export PORT="$PORT"
export DATA_DIR="$DATA_DIR"
nohup python3 server.py > server.log 2>&1 &
NEW_PID=$!
echo $NEW_PID > server.pid

ok "后端已启动，PID: $NEW_PID"

# 健康检查
info "等待服务启动..."
sleep 2

HEALTH_URL="http://localhost:${PORT}/api/health"
for i in 1 2 3; do
    if curl -s "$HEALTH_URL" > /dev/null 2>&1; then
        ok "服务运行正常！"
        RESPONSE=$(curl -s "$HEALTH_URL")
        echo "  响应: $RESPONSE"
        break
    else
        if [ "$i" -eq 3 ]; then
            warn "健康检查未通过，查看日志..."
            tail -n 20 server.log
        else
            sleep 1
        fi
    fi
done

# 完成信息
echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  部署完成！${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "服务地址: ${BLUE}http://$SERVER_IP:$PORT${NC}"
echo -e "健康检查: ${BLUE}curl http://$SERVER_IP:$PORT/api/health${NC}"
echo -e "查询记录: ${BLUE}curl http://$SERVER_IP:$PORT/api/records?student=萱萱${NC}"
echo ""
echo -e "常用命令:"
echo "  cat server.log         - 查看日志"
echo "  cat server.pid         - 查看当前PID"
echo "  kill \$(cat server.pid) - 停止服务"
echo "  ps aux | grep server.py - 查看进程"
echo ""
echo -e "数据目录: ${BLUE}$(pwd)/$DATA_DIR${NC}"
echo -e "日志文件: ${BLUE}$(pwd)/server.log${NC}"
echo ""
echo -e "${YELLOW}重要提醒：${NC}"
echo "请登录阿里云控制台 → ECS → 安全组 → 配置规则"
echo "添加入方向规则：自定义TCP，端口 $PORT，授权对象 0.0.0.0/0"
echo ""
echo -e "${GREEN}萱萱的数据会自动飞到这里 ${NC}"
